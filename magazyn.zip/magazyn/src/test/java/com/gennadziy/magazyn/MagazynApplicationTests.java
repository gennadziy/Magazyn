package com.gennadziy.magazyn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MagazynApplicationTests {

	@Test
	void contextLoads() {
	}

}
